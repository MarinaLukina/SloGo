<?php
$mysqli = mysqli_connect("localhost", "f0576270_Frontend2021", "45612", "f0576270_Frontend2021");